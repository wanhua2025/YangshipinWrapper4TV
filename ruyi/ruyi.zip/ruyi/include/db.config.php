<?php
define('DB_HOST','localhost');//数据库连接地址，默认：localhost 或127.0.0.1
define('DB_USER','kaiyuan_ruyi');//数据库账号
define('DB_PASSWD','WeJSxnbEC6GRKJ6s');//数据库密码
define('DB_NAME','kaiyuan_ruyi');//数据库名称
define('DB_PRE','yyys_');//数据库前缀
?>